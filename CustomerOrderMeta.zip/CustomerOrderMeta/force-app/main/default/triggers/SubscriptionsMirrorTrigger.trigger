trigger SubscriptionsMirrorTrigger on SBQQ__Subscription__c (after insert, after update, after delete, after undelete) {
    SubscriptionMirrorTriggerHelper.run(Trigger.New, Trigger.Old);
}